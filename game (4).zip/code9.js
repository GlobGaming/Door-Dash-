gdjs.a_32figure_32ripoffCode = {};
gdjs.a_32figure_32ripoffCode.GDNewTiledSpriteObjects1= [];
gdjs.a_32figure_32ripoffCode.GDNewTiledSpriteObjects2= [];
gdjs.a_32figure_32ripoffCode.GDNewSpriteObjects1= [];
gdjs.a_32figure_32ripoffCode.GDNewSpriteObjects2= [];
gdjs.a_32figure_32ripoffCode.GDNewSprite2Objects1= [];
gdjs.a_32figure_32ripoffCode.GDNewSprite2Objects2= [];
gdjs.a_32figure_32ripoffCode.GDNewSprite3Objects1= [];
gdjs.a_32figure_32ripoffCode.GDNewSprite3Objects2= [];
gdjs.a_32figure_32ripoffCode.GDNewSprite4Objects1= [];
gdjs.a_32figure_32ripoffCode.GDNewSprite4Objects2= [];
gdjs.a_32figure_32ripoffCode.GDNewTiledSprite2Objects1= [];
gdjs.a_32figure_32ripoffCode.GDNewTiledSprite2Objects2= [];
gdjs.a_32figure_32ripoffCode.GDNewSprite5Objects1= [];
gdjs.a_32figure_32ripoffCode.GDNewSprite5Objects2= [];
gdjs.a_32figure_32ripoffCode.GDPurpleButtonWithShadowObjects1= [];
gdjs.a_32figure_32ripoffCode.GDPurpleButtonWithShadowObjects2= [];
gdjs.a_32figure_32ripoffCode.GDBlueButtonWithShadowObjects1= [];
gdjs.a_32figure_32ripoffCode.GDBlueButtonWithShadowObjects2= [];
gdjs.a_32figure_32ripoffCode.GDRedButtonWithShadowObjects1= [];
gdjs.a_32figure_32ripoffCode.GDRedButtonWithShadowObjects2= [];
gdjs.a_32figure_32ripoffCode.GDGreenButtonWithShadowObjects1= [];
gdjs.a_32figure_32ripoffCode.GDGreenButtonWithShadowObjects2= [];
gdjs.a_32figure_32ripoffCode.GDNewSprite6Objects1= [];
gdjs.a_32figure_32ripoffCode.GDNewSprite6Objects2= [];
gdjs.a_32figure_32ripoffCode.GDNewBBTextObjects1= [];
gdjs.a_32figure_32ripoffCode.GDNewBBTextObjects2= [];


gdjs.a_32figure_32ripoffCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("Score").setNumber(0);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "TimeLeft");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GreenButtonWithShadow"), gdjs.a_32figure_32ripoffCode.GDGreenButtonWithShadowObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.a_32figure_32ripoffCode.GDGreenButtonWithShadowObjects1.length;i<l;++i) {
    if ( gdjs.a_32figure_32ripoffCode.GDGreenButtonWithShadowObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.a_32figure_32ripoffCode.GDGreenButtonWithShadowObjects1[k] = gdjs.a_32figure_32ripoffCode.GDGreenButtonWithShadowObjects1[i];
        ++k;
    }
}
gdjs.a_32figure_32ripoffCode.GDGreenButtonWithShadowObjects1.length = k;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("Score").add(1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.doesSceneExist(runtimeScene, "a figure ripoff");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBBText"), gdjs.a_32figure_32ripoffCode.GDNewBBTextObjects1);
{for(var i = 0, len = gdjs.a_32figure_32ripoffCode.GDNewBBTextObjects1.length ;i < len;++i) {
    gdjs.a_32figure_32ripoffCode.GDNewBBTextObjects1[i].setBBText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Score"))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("RedButtonWithShadow"), gdjs.a_32figure_32ripoffCode.GDRedButtonWithShadowObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.a_32figure_32ripoffCode.GDRedButtonWithShadowObjects1.length;i<l;++i) {
    if ( gdjs.a_32figure_32ripoffCode.GDRedButtonWithShadowObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.a_32figure_32ripoffCode.GDRedButtonWithShadowObjects1[k] = gdjs.a_32figure_32ripoffCode.GDRedButtonWithShadowObjects1[i];
        ++k;
    }
}
gdjs.a_32figure_32ripoffCode.GDRedButtonWithShadowObjects1.length = k;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("Score").add(1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlueButtonWithShadow"), gdjs.a_32figure_32ripoffCode.GDBlueButtonWithShadowObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.a_32figure_32ripoffCode.GDBlueButtonWithShadowObjects1.length;i<l;++i) {
    if ( gdjs.a_32figure_32ripoffCode.GDBlueButtonWithShadowObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.a_32figure_32ripoffCode.GDBlueButtonWithShadowObjects1[k] = gdjs.a_32figure_32ripoffCode.GDBlueButtonWithShadowObjects1[i];
        ++k;
    }
}
gdjs.a_32figure_32ripoffCode.GDBlueButtonWithShadowObjects1.length = k;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("Score").add(1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "TimeLeft") >= 10;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Score")) < 20;
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Died To phantom", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Score")) > 20;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "TimeLeft") >= 10;
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "The FInale...", false);
}}

}


};

gdjs.a_32figure_32ripoffCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.a_32figure_32ripoffCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.a_32figure_32ripoffCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.a_32figure_32ripoffCode.GDNewSpriteObjects1.length = 0;
gdjs.a_32figure_32ripoffCode.GDNewSpriteObjects2.length = 0;
gdjs.a_32figure_32ripoffCode.GDNewSprite2Objects1.length = 0;
gdjs.a_32figure_32ripoffCode.GDNewSprite2Objects2.length = 0;
gdjs.a_32figure_32ripoffCode.GDNewSprite3Objects1.length = 0;
gdjs.a_32figure_32ripoffCode.GDNewSprite3Objects2.length = 0;
gdjs.a_32figure_32ripoffCode.GDNewSprite4Objects1.length = 0;
gdjs.a_32figure_32ripoffCode.GDNewSprite4Objects2.length = 0;
gdjs.a_32figure_32ripoffCode.GDNewTiledSprite2Objects1.length = 0;
gdjs.a_32figure_32ripoffCode.GDNewTiledSprite2Objects2.length = 0;
gdjs.a_32figure_32ripoffCode.GDNewSprite5Objects1.length = 0;
gdjs.a_32figure_32ripoffCode.GDNewSprite5Objects2.length = 0;
gdjs.a_32figure_32ripoffCode.GDPurpleButtonWithShadowObjects1.length = 0;
gdjs.a_32figure_32ripoffCode.GDPurpleButtonWithShadowObjects2.length = 0;
gdjs.a_32figure_32ripoffCode.GDBlueButtonWithShadowObjects1.length = 0;
gdjs.a_32figure_32ripoffCode.GDBlueButtonWithShadowObjects2.length = 0;
gdjs.a_32figure_32ripoffCode.GDRedButtonWithShadowObjects1.length = 0;
gdjs.a_32figure_32ripoffCode.GDRedButtonWithShadowObjects2.length = 0;
gdjs.a_32figure_32ripoffCode.GDGreenButtonWithShadowObjects1.length = 0;
gdjs.a_32figure_32ripoffCode.GDGreenButtonWithShadowObjects2.length = 0;
gdjs.a_32figure_32ripoffCode.GDNewSprite6Objects1.length = 0;
gdjs.a_32figure_32ripoffCode.GDNewSprite6Objects2.length = 0;
gdjs.a_32figure_32ripoffCode.GDNewBBTextObjects1.length = 0;
gdjs.a_32figure_32ripoffCode.GDNewBBTextObjects2.length = 0;

gdjs.a_32figure_32ripoffCode.eventsList0(runtimeScene);

return;

}

gdjs['a_32figure_32ripoffCode'] = gdjs.a_32figure_32ripoffCode;
