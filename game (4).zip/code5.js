gdjs.Untitled_32scene5Code = {};
gdjs.Untitled_32scene5Code.GDNewSpriteObjects1= [];
gdjs.Untitled_32scene5Code.GDNewSpriteObjects2= [];
gdjs.Untitled_32scene5Code.GDNewSprite2Objects1= [];
gdjs.Untitled_32scene5Code.GDNewSprite2Objects2= [];
gdjs.Untitled_32scene5Code.GDNewTiledSpriteObjects1= [];
gdjs.Untitled_32scene5Code.GDNewTiledSpriteObjects2= [];
gdjs.Untitled_32scene5Code.GDNewSprite3Objects1= [];
gdjs.Untitled_32scene5Code.GDNewSprite3Objects2= [];


gdjs.Untitled_32scene5Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32scene5Code.GDNewSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32scene5Code.GDNewSpriteObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32scene5Code.GDNewSpriteObjects1[i].hasAnimationEnded2() ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32scene5Code.GDNewSpriteObjects1[k] = gdjs.Untitled_32scene5Code.GDNewSpriteObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32scene5Code.GDNewSpriteObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "chase", false);
}}

}


};

gdjs.Untitled_32scene5Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32scene5Code.GDNewSpriteObjects1.length = 0;
gdjs.Untitled_32scene5Code.GDNewSpriteObjects2.length = 0;
gdjs.Untitled_32scene5Code.GDNewSprite2Objects1.length = 0;
gdjs.Untitled_32scene5Code.GDNewSprite2Objects2.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSpriteObjects1.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSpriteObjects2.length = 0;
gdjs.Untitled_32scene5Code.GDNewSprite3Objects1.length = 0;
gdjs.Untitled_32scene5Code.GDNewSprite3Objects2.length = 0;

gdjs.Untitled_32scene5Code.eventsList0(runtimeScene);

return;

}

gdjs['Untitled_32scene5Code'] = gdjs.Untitled_32scene5Code;
