gdjs.The_32End_58_32GOod_32endingCode = {};
gdjs.The_32End_58_32GOod_32endingCode.GDNewSpriteObjects1= [];
gdjs.The_32End_58_32GOod_32endingCode.GDNewSpriteObjects2= [];


gdjs.The_32End_58_32GOod_32endingCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.The_32End_58_32GOod_32endingCode.GDNewSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.The_32End_58_32GOod_32endingCode.GDNewSpriteObjects1.length;i<l;++i) {
    if ( gdjs.The_32End_58_32GOod_32endingCode.GDNewSpriteObjects1[i].hasAnimationEnded2() ) {
        isConditionTrue_0 = true;
        gdjs.The_32End_58_32GOod_32endingCode.GDNewSpriteObjects1[k] = gdjs.The_32End_58_32GOod_32endingCode.GDNewSpriteObjects1[i];
        ++k;
    }
}
gdjs.The_32End_58_32GOod_32endingCode.GDNewSpriteObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "good job..", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "foundations.mp3", false, 75, 1);
}}

}


};

gdjs.The_32End_58_32GOod_32endingCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.The_32End_58_32GOod_32endingCode.GDNewSpriteObjects1.length = 0;
gdjs.The_32End_58_32GOod_32endingCode.GDNewSpriteObjects2.length = 0;

gdjs.The_32End_58_32GOod_32endingCode.eventsList0(runtimeScene);

return;

}

gdjs['The_32End_58_32GOod_32endingCode'] = gdjs.The_32End_58_32GOod_32endingCode;
