gdjs.Untitled_32scene3Code = {};
gdjs.Untitled_32scene3Code.GDNewSpriteObjects1= [];
gdjs.Untitled_32scene3Code.GDNewSpriteObjects2= [];
gdjs.Untitled_32scene3Code.GDNewTiledSpriteObjects1= [];
gdjs.Untitled_32scene3Code.GDNewTiledSpriteObjects2= [];
gdjs.Untitled_32scene3Code.GDPlayerObjects1= [];
gdjs.Untitled_32scene3Code.GDPlayerObjects2= [];
gdjs.Untitled_32scene3Code.GDNewSprite2Objects1= [];
gdjs.Untitled_32scene3Code.GDNewSprite2Objects2= [];
gdjs.Untitled_32scene3Code.GDNewTiledSprite2Objects1= [];
gdjs.Untitled_32scene3Code.GDNewTiledSprite2Objects2= [];
gdjs.Untitled_32scene3Code.GDNewBBTextObjects1= [];
gdjs.Untitled_32scene3Code.GDNewBBTextObjects2= [];
gdjs.Untitled_32scene3Code.GDNewBBText2Objects1= [];
gdjs.Untitled_32scene3Code.GDNewBBText2Objects2= [];
gdjs.Untitled_32scene3Code.GDNewSprite3Objects1= [];
gdjs.Untitled_32scene3Code.GDNewSprite3Objects2= [];


gdjs.Untitled_32scene3Code.mapOfGDgdjs_9546Untitled_959532scene3Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Untitled_32scene3Code.GDPlayerObjects1});
gdjs.Untitled_32scene3Code.mapOfGDgdjs_9546Untitled_959532scene3Code_9546GDNewSprite3Objects1Objects = Hashtable.newFrom({"NewSprite3": gdjs.Untitled_32scene3Code.GDNewSprite3Objects1});
gdjs.Untitled_32scene3Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.Untitled_32scene3Code.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NewSprite3"), gdjs.Untitled_32scene3Code.GDNewSprite3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32scene3Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32scene3Code.mapOfGDgdjs_9546Untitled_959532scene3Code_9546GDPlayerObjects1Objects, gdjs.Untitled_32scene3Code.mapOfGDgdjs_9546Untitled_959532scene3Code_9546GDNewSprite3Objects1Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "time_to_think (1).mp3", true, 75, 1);
}{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Untitled scene5");
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Untitled_32scene3Code.eventsList0(runtimeScene);} //End of subevents
}

}


};

gdjs.Untitled_32scene3Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32scene3Code.GDNewSpriteObjects1.length = 0;
gdjs.Untitled_32scene3Code.GDNewSpriteObjects2.length = 0;
gdjs.Untitled_32scene3Code.GDNewTiledSpriteObjects1.length = 0;
gdjs.Untitled_32scene3Code.GDNewTiledSpriteObjects2.length = 0;
gdjs.Untitled_32scene3Code.GDPlayerObjects1.length = 0;
gdjs.Untitled_32scene3Code.GDPlayerObjects2.length = 0;
gdjs.Untitled_32scene3Code.GDNewSprite2Objects1.length = 0;
gdjs.Untitled_32scene3Code.GDNewSprite2Objects2.length = 0;
gdjs.Untitled_32scene3Code.GDNewTiledSprite2Objects1.length = 0;
gdjs.Untitled_32scene3Code.GDNewTiledSprite2Objects2.length = 0;
gdjs.Untitled_32scene3Code.GDNewBBTextObjects1.length = 0;
gdjs.Untitled_32scene3Code.GDNewBBTextObjects2.length = 0;
gdjs.Untitled_32scene3Code.GDNewBBText2Objects1.length = 0;
gdjs.Untitled_32scene3Code.GDNewBBText2Objects2.length = 0;
gdjs.Untitled_32scene3Code.GDNewSprite3Objects1.length = 0;
gdjs.Untitled_32scene3Code.GDNewSprite3Objects2.length = 0;

gdjs.Untitled_32scene3Code.eventsList1(runtimeScene);

return;

}

gdjs['Untitled_32scene3Code'] = gdjs.Untitled_32scene3Code;
