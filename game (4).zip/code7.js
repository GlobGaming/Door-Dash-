gdjs.die_32to_32runnerCode = {};
gdjs.die_32to_32runnerCode.GDNewBBTextObjects1= [];
gdjs.die_32to_32runnerCode.GDNewBBTextObjects2= [];


gdjs.die_32to_32runnerCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBBText"), gdjs.die_32to_32runnerCode.GDNewBBTextObjects1);
{for(var i = 0, len = gdjs.die_32to_32runnerCode.GDNewBBTextObjects1.length ;i < len;++i) {
    gdjs.die_32to_32runnerCode.GDNewBBTextObjects1[i].setBBText("Oh, hello.");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 2;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBBText"), gdjs.die_32to_32runnerCode.GDNewBBTextObjects1);
{for(var i = 0, len = gdjs.die_32to_32runnerCode.GDNewBBTextObjects1.length ;i < len;++i) {
    gdjs.die_32to_32runnerCode.GDNewBBTextObjects1[i].setBBText(" I'm pretty sure you died\nto Nightstalker, ");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 3;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBBText"), gdjs.die_32to_32runnerCode.GDNewBBTextObjects1);
{for(var i = 0, len = gdjs.die_32to_32runnerCode.GDNewBBTextObjects1.length ;i < len;++i) {
    gdjs.die_32to_32runnerCode.GDNewBBTextObjects1[i].setBBText(" Nightstalker is a being that chases you down the hallway, ");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 4;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBBText"), gdjs.die_32to_32runnerCode.GDNewBBTextObjects1);
{for(var i = 0, len = gdjs.die_32to_32runnerCode.GDNewBBTextObjects1.length ;i < len;++i) {
    gdjs.die_32to_32runnerCode.GDNewBBTextObjects1[i].setBBText("You must click any key to run, i suggest using 2 or more buttons.");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 5;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBBText"), gdjs.die_32to_32runnerCode.GDNewBBTextObjects1);
{for(var i = 0, len = gdjs.die_32to_32runnerCode.GDNewBBTextObjects1.length ;i < len;++i) {
    gdjs.die_32to_32runnerCode.GDNewBBTextObjects1[i].setBBText(" Who am I? I'm Mortus, ");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 6;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Untitled scene", false);
}}

}


};

gdjs.die_32to_32runnerCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.die_32to_32runnerCode.GDNewBBTextObjects1.length = 0;
gdjs.die_32to_32runnerCode.GDNewBBTextObjects2.length = 0;

gdjs.die_32to_32runnerCode.eventsList0(runtimeScene);

return;

}

gdjs['die_32to_32runnerCode'] = gdjs.die_32to_32runnerCode;
