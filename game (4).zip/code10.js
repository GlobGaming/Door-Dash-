gdjs.Died_32To_32phantomCode = {};
gdjs.Died_32To_32phantomCode.GDNewBitmapTextObjects1= [];
gdjs.Died_32To_32phantomCode.GDNewBitmapTextObjects2= [];
gdjs.Died_32To_32phantomCode.GDNewTextObjects1= [];
gdjs.Died_32To_32phantomCode.GDNewTextObjects2= [];


gdjs.Died_32To_32phantomCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("a").add(1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("a")) == 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.Died_32To_32phantomCode.GDNewTextObjects1);
{for(var i = 0, len = gdjs.Died_32To_32phantomCode.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.Died_32To_32phantomCode.GDNewTextObjects1[i].setString(" Ah, another curious soul seeks guidance. Welcome, my friend. I am the Guiding Light, here to help you on your chosen path. ");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("a")) == 2;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.Died_32To_32phantomCode.GDNewTextObjects1);
{for(var i = 0, len = gdjs.Died_32To_32phantomCode.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.Died_32To_32phantomCode.GDNewTextObjects1[i].setString(" Ah, this room holds a challenge for you, young adventurer. To overcome it, you must exhibit both speed and precision. Listen closely, for time is of the essence. ");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("a")) == 3;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.Died_32To_32phantomCode.GDNewTextObjects1);
{for(var i = 0, len = gdjs.Died_32To_32phantomCode.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.Died_32To_32phantomCode.GDNewTextObjects1[i].setString("  Your task is to click the buttons before you a total of 20 times, within the span of just 10 seconds. ");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("a")) == 4;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.Died_32To_32phantomCode.GDNewTextObjects1);
{for(var i = 0, len = gdjs.Died_32To_32phantomCode.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.Died_32To_32phantomCode.GDNewTextObjects1[i].setString(" Clicking the buttons is a test of your reflexes and focus. By accomplishing this task, you prove yourself worthy to progress further. ");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("a")) == 5;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.Died_32To_32phantomCode.GDNewTextObjects1);
{for(var i = 0, len = gdjs.Died_32To_32phantomCode.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.Died_32To_32phantomCode.GDNewTextObjects1[i].setString(" Be warned, though: failure to complete the task in the allotted time will result in the arrival of the Phantom, a force best left unencountered. ");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("a")) == 6;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.Died_32To_32phantomCode.GDNewTextObjects1);
{for(var i = 0, len = gdjs.Died_32To_32phantomCode.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.Died_32To_32phantomCode.GDNewTextObjects1[i].setString(" Fear not, for I shall be your guiding beacon in this endeavor. Focus on the buttons before you and click them swiftly, but with accuracy ");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("a")) == 7;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.Died_32To_32phantomCode.GDNewTextObjects1);
{for(var i = 0, len = gdjs.Died_32To_32phantomCode.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.Died_32To_32phantomCode.GDNewTextObjects1[i].setString("  I have faith in your abilities, young adventurer. May fortune favor the brave. Now, go forth and conquer this trial. Do not let the Phantom's presence be your fate. Click the buttons 20 times within 10 seconds, and your path shall unfold. ");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("a")) == 8;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Untitled scene", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("a")) == 9;
if (isConditionTrue_0) {
}

}


};

gdjs.Died_32To_32phantomCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Died_32To_32phantomCode.GDNewBitmapTextObjects1.length = 0;
gdjs.Died_32To_32phantomCode.GDNewBitmapTextObjects2.length = 0;
gdjs.Died_32To_32phantomCode.GDNewTextObjects1.length = 0;
gdjs.Died_32To_32phantomCode.GDNewTextObjects2.length = 0;

gdjs.Died_32To_32phantomCode.eventsList0(runtimeScene);

return;

}

gdjs['Died_32To_32phantomCode'] = gdjs.Died_32To_32phantomCode;
