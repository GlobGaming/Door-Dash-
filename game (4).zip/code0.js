gdjs.Untitled_32sceneCode = {};
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects2= [];
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1= [];
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects2= [];
gdjs.Untitled_32sceneCode.GDNewSprite2Objects1= [];
gdjs.Untitled_32sceneCode.GDNewSprite2Objects2= [];
gdjs.Untitled_32sceneCode.GDMedievalButtonBeigeObjects1= [];
gdjs.Untitled_32sceneCode.GDMedievalButtonBeigeObjects2= [];
gdjs.Untitled_32sceneCode.GDMedievalButtonBeige2Objects1= [];
gdjs.Untitled_32sceneCode.GDMedievalButtonBeige2Objects2= [];


gdjs.Untitled_32sceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.playerAuthentication.displayAuthenticationBanner(runtimeScene);
}{gdjs.evtTools.sound.playMusic(runtimeScene, "stagnation.mp3", true, 75, 1);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MedievalButtonBeige"), gdjs.Untitled_32sceneCode.GDMedievalButtonBeigeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDMedievalButtonBeigeObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDMedievalButtonBeigeObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDMedievalButtonBeigeObjects1[k] = gdjs.Untitled_32sceneCode.GDMedievalButtonBeigeObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDMedievalButtonBeigeObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Untitled scene2", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("MedievalButtonBeige2"), gdjs.Untitled_32sceneCode.GDMedievalButtonBeige2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDMedievalButtonBeige2Objects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDMedievalButtonBeige2Objects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDMedievalButtonBeige2Objects1[k] = gdjs.Untitled_32sceneCode.GDMedievalButtonBeige2Objects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDMedievalButtonBeige2Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Credits", false);
}}

}


};

gdjs.Untitled_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDMedievalButtonBeigeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDMedievalButtonBeigeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDMedievalButtonBeige2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDMedievalButtonBeige2Objects2.length = 0;

gdjs.Untitled_32sceneCode.eventsList0(runtimeScene);

return;

}

gdjs['Untitled_32sceneCode'] = gdjs.Untitled_32sceneCode;
