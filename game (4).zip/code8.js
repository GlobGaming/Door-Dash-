gdjs.other_32thingCode = {};
gdjs.other_32thingCode.GDNewSpriteObjects1= [];
gdjs.other_32thingCode.GDNewSpriteObjects2= [];
gdjs.other_32thingCode.GDPlayerObjects1= [];
gdjs.other_32thingCode.GDPlayerObjects2= [];
gdjs.other_32thingCode.GDNewTiledSprite2Objects1= [];
gdjs.other_32thingCode.GDNewTiledSprite2Objects2= [];
gdjs.other_32thingCode.GDNewSprite2Objects1= [];
gdjs.other_32thingCode.GDNewSprite2Objects2= [];
gdjs.other_32thingCode.GDNewTiledSpriteObjects1= [];
gdjs.other_32thingCode.GDNewTiledSpriteObjects2= [];
gdjs.other_32thingCode.GDNewSprite3Objects1= [];
gdjs.other_32thingCode.GDNewSprite3Objects2= [];
gdjs.other_32thingCode.GDMedievalButtonBrownObjects1= [];
gdjs.other_32thingCode.GDMedievalButtonBrownObjects2= [];


gdjs.other_32thingCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("MedievalButtonBrown"), gdjs.other_32thingCode.GDMedievalButtonBrownObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.other_32thingCode.GDMedievalButtonBrownObjects1.length;i<l;++i) {
    if ( gdjs.other_32thingCode.GDMedievalButtonBrownObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.other_32thingCode.GDMedievalButtonBrownObjects1[k] = gdjs.other_32thingCode.GDMedievalButtonBrownObjects1[i];
        ++k;
    }
}
gdjs.other_32thingCode.GDMedievalButtonBrownObjects1.length = k;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("'afwev").add(1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("'afwev")) == 10;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "a figure ripoff", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.other_32thingCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.other_32thingCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.other_32thingCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.other_32thingCode.GDPlayerObjects1[k] = gdjs.other_32thingCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.other_32thingCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Jump 4.aac", 2, false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.other_32thingCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.other_32thingCode.GDNewSpriteObjects1.length = 0;
gdjs.other_32thingCode.GDNewSpriteObjects2.length = 0;
gdjs.other_32thingCode.GDPlayerObjects1.length = 0;
gdjs.other_32thingCode.GDPlayerObjects2.length = 0;
gdjs.other_32thingCode.GDNewTiledSprite2Objects1.length = 0;
gdjs.other_32thingCode.GDNewTiledSprite2Objects2.length = 0;
gdjs.other_32thingCode.GDNewSprite2Objects1.length = 0;
gdjs.other_32thingCode.GDNewSprite2Objects2.length = 0;
gdjs.other_32thingCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.other_32thingCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.other_32thingCode.GDNewSprite3Objects1.length = 0;
gdjs.other_32thingCode.GDNewSprite3Objects2.length = 0;
gdjs.other_32thingCode.GDMedievalButtonBrownObjects1.length = 0;
gdjs.other_32thingCode.GDMedievalButtonBrownObjects2.length = 0;

gdjs.other_32thingCode.eventsList0(runtimeScene);

return;

}

gdjs['other_32thingCode'] = gdjs.other_32thingCode;
